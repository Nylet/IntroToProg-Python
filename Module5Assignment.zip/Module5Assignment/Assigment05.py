#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   SHouser, 11/13/2016, Added code to complete assignment 5
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

objFileName = "C:\_PythonClass\Module5Assignment\ToDo.txt"
strData = ""
dicTable = {}

# Step 1
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary.
txt = open(objFileName,"r") #open the text file and define its variable

for line in txt:
    strData = line #converts line into variable
    lstData = strData.split(",") #converts the line into two separate elements
    dicTable[lstData[0].strip()] = lstData[1].strip() #puts the first element as key, second as value
txt.close() #close the txt file

# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show the current task list
    2) Add a new task
    3) Remove a task from the list
    4) Save your task list
    5) Exit
    """)
    strChoice = str(input("Which action would you like to perform? [1 to 4] - "))
    print()#add blank line for aesthetics

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("--- You currently have the following items To Do: ---")
        for strKey,strVal in dicTable.items():
            print("Task: " + strKey + " / Priority: " + strVal)
        continue

    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        taskName = str(input("What is the name of the task?"))
        taskPri = str(input("What priority level is the task?"))
        dicTable[taskName] = taskPri #creates a row in the dictionary with the first input as key, second as value
        continue

    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        for strKey, strVal in dicTable.items():
            print(strKey) #print the task names to choose from
        taskRem = input("Please type the name of the task you would like to remove.")
        if (taskRem in dicTable):
            del dicTable[taskRem] #if that exact task is found that related key and value are deleted
        else:
            print("I'm sorry, I cannot find that task.")
        continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        print("--- You currently have the following items To Do: ---")
        for strKey, strVal in dicTable.items():
            print("Task: " + strKey + " / Priority: " + strVal)
        if ("y" == str(input("Would you like to save this task list? (y/n) - ")).strip().lower()):
            txt = open(objFileName, "w") #open and write
            txt.truncate(0) #delete data to avoid duplication
            for strKey, strVal in dicTable.items():
                txt.write(strKey + "," + strVal + "\n") #write the entries in the same format for reading
            txt.close()
            input("Your task list has been saved. Please press [Enter] to see the menu.")
        else:
            input("Your list has not been saved. Please press [Enter] to see the menu.")
        continue  #to show the menu

    elif (strChoice == '5'):
        print("Goodbye! Have a productive day!")
        break #end the program

