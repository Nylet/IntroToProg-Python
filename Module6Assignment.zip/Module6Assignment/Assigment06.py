#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   SHouser, 11/13/2016, Added code to complete assignment 5
#   SHouser, 11/20/2016, Modified code to complete assignment 6 for classes and functions
#-------------------------------------------------#

# -- data code --
objFileName = "C:\_PythonClass\Module6Assignment\ToDo.txt"
strData = ""
dicTable = {}

# --processing code--

class BackgroundProcess:
    @staticmethod
    def LoadDataFromFile():
        ''' Function loads ToDo.txt file data'''
        txt = open(objFileName, "r")  # open the text file and define its variable
        for line in txt:
            strData = line  # converts line into variable
            lstData = strData.split(",")  # converts the line into two separate elements
            dicTable[lstData[0].strip()] = lstData[1].strip()  # puts the first element as key, second as value
        txt.close()  # close the txt file

    def WipeWriteSaveClose():
        '''Wipes the files, writes everything in the program, saves, and closes the file.'''
        txt = open(objFileName, "w")  # open and write
        txt.truncate(0)  # delete data to avoid duplication
        for strKey, strVal in dicTable.items():
            txt.write(strKey + "," + strVal + "\n")  # write the entries in the same format for reading
        txt.close()

    def CreateTaskRow(taskname, taskpri):
        '''Takes passed in user input and creates dictionary entry.'''
        dicTable[taskname] = taskpri  # creates a row in the dictionary with the first input as key, second as value

class UserFacing:
    @staticmethod
    def PrintCurrentList():
        '''Prints current data in the ToDo list.'''
        print("--- You currently have the following items To Do: ---")
        for strKey, strVal in dicTable.items():
            print("Task: " + strKey + " / Priority: " + strVal)
    def TaskKeyList():
        '''Prints current task names which serve as dictionary keys'''
        for strKey, strVal in dicTable.items():
            print(strKey)  # print the task names to choose from
    def GetNewTask():
        '''Solicits user for task and priority and passes input in for processing'''
        taskname = str(input("What is the name of the task?"))
        taskpri = str(input("What priority level is the task?"))
        return taskname, taskpri
    def RemoveTask():
        taskRem = input("Please type the name of the task you would like to remove.")
        if (taskRem in dicTable):
            del dicTable[taskRem]  # if that exact task is found that related key and value are deleted
        else:
            print("I'm sorry, I cannot find that task.")
    def MainMenu():
        '''Displays menu to solicit user choice'''
        print("""
            Menu of Options
            1) Show the current task list
            2) Add a new task
            3) Remove a task from the list
            4) Save your task list
            5) Exit
            """)
        strChoice = str(input("Which action would you like to perform? [1 to 5] - "))
        print()  # add blank line for aesthetics
        return strChoice


# --presentation (I/0) code--

BackgroundProcess.LoadDataFromFile() #calls function to load data from ToDo.txt

while(True):
    strChoice = UserFacing.MainMenu()

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        UserFacing.PrintCurrentList() #prints the current ToDo list
        continue

    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        taskname, taskpri = UserFacing.GetNewTask()
        BackgroundProcess.CreateTaskRow(taskname, taskpri)
        continue

    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        UserFacing.TaskKeyList()
        UserFacing.RemoveTask()
        continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        UserFacing.PrintCurrentList()
        if ("y" == str(input("Would you like to save this task list? (y/n) - ")).strip().lower()):
            BackgroundProcess.WipeWriteSaveClose()
            input("Your task list has been saved. Please press [Enter] to see the menu.")
        else:
            input("Your list has not been saved. Please press [Enter] to see the menu.")
        continue  #to show the menu

    elif (strChoice == '5'):
        print("Goodbye! Have a productive day!")
        break #end the program

